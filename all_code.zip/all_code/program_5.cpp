#include <iostream>
#include <mpi.h>
#include <vector>

using namespace std;

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv); // Initialize the MPI environment

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); // Get the rank of the process
    MPI_Comm_size(MPI_COMM_WORLD, &size); // Get the number of processes

    // Ensure there are exactly two processes
    if (size != 2) {
        cerr << "This program requires exactly 2 processes." << endl;
        MPI_Finalize();
        return 1;
    }

    const int N = 1000; // Size of the array
    vector<int> array(N, 1); // Initialize array with 1s

    double start_time = MPI_Wtime(); // Start the timer

    // Each process computes a partial sum of the array
    long long partial_sum = 0;
    int start_index = rank * (N / 2);
    int end_index = (rank == size - 1) ? N : (rank + 1) * (N / 2);

    for (int i = start_index; i < end_index; ++i) {
        partial_sum += array[i];
    }

    long long total_sum = 0;
    MPI_Reduce(&partial_sum, &total_sum, 1, MPI_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);

    double end_time = MPI_Wtime(); // End the timer

    if (rank == 0) {
        cout << "Total sum: " << total_sum << endl;
        cout << "Time taken: " << end_time - start_time << " seconds" << endl;
    }

    MPI_Finalize(); // Finalize the MPI environment
    return 0;
}
