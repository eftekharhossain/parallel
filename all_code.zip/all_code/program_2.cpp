#include <mpi.h>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    // Initialize the MPI environment
    MPI_Init(&argc, &argv);

    // Get the rank of the process
    int world_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

    // Define two operands for demonstration
    double operand1 = 10.0;
    double operand2 = 5.0;
    double result;

    // Perform different operations based on the process rank
    switch (world_rank) {
        case 0: // Process 0 performs addition
            result = operand1 + operand2;
            cout << "Addition: " << operand1 << " + " << operand2 << " = " << result << endl;
            break;
        case 1: // Process 1 performs subtraction
            result = operand1 - operand2;
            cout << "Subtraction: " << operand1 << " - " << operand2 << " = " << result << endl;
            break;
        case 2: // Process 2 performs multiplication
            result = operand1 * operand2;
            cout << "Multiplication: " << operand1 << " * " << operand2 << " = " << result << endl;
            break;
        case 3: // Process 3 performs division, with check for division by zero
            if (operand2 != 0) {
                result = operand1 / operand2;
                cout << "Division: " << operand1 << " / " << operand2 << " = " << result << endl;
            } else {
                cout << "Division: Error - Division by Zero" << endl;
            }
            break;
        default:
            cout << "No operation assigned to process " << world_rank << endl;
    }

    // Finalize the MPI environment
    MPI_Finalize();
    return 0;
}
