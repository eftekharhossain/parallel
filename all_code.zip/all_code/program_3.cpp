#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

// Function to split a string into words
vector<string> splitIntoWords(const string& line) {
    stringstream ss(line);
    string word;
    vector<string> words;
    while (ss >> word) {
        words.push_back(word);
    }
    return words;
}

int main() {
    // Change to the name of the file
    string filename = "sample.txt";
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Unable to open file " << filename << endl;
        return 1;
    }

    map<string, int> wordCount;
    string line;
    // Read file line by line
    while (getline(file, line)) {
        vector<string> words = splitIntoWords(line);
        // Count each word
        for (const string& word : words) {
            wordCount[word]++;
        }
    }

    file.close();

    // Transfer to a vector for sorting
    vector<pair<string, int>> wordFreq(wordCount.begin(), wordCount.end());
    // Sort in descending order of frequency
    sort(wordFreq.begin(), wordFreq.end(), [](const pair<string, int>& a, const pair<string, int>& b) {
        return a.second > b.second;
    });

    // Print sorted words and their frequencies
    for (const auto& pair : wordFreq) {
        cout << pair.first << ": " << pair.second << " times" << endl;
    }

    return 0;
}
