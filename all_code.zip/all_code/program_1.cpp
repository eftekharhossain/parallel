#include <mpi.h>
#include <iostream>
#include <vector>

using namespace std;

// Function to multiply a part of the matrix
void multiplyMatrixPart(const vector<vector<int>>& A, const vector<vector<int>>& B, vector<vector<int>>& C, int startRow, int endRow, int N, int P) {
    for (int i = startRow; i < endRow; ++i) {
        for (int j = 0; j < P; ++j) {
            C[i][j] = 0;
            for (int k = 0; k < N; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int world_size;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    int world_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

    // Matrix dimensions (MxN and NxP)
    const int M = 3; // Number of rows in matrix A
    const int N = 3; // Number of columns in matrix A and rows in matrix B
    const int P = 3; // Number of columns in matrix B

    // Initialize matrices A, B, and C
    // vector<vector<int>> A(M, vector<int>(N, 1)); // Initialize with 1 for simplicity
    // vector<vector<int>> B(N, vector<int>(P, 1)); // Initialize with 1 for simplicity
    vector<vector<int>> C(M, vector<int>(P, 0)); // Result matrix

    vector<vector<int>> A = {{1, 2, 3},
                            {4, 5, 6},
                            {7, 8, 9}};
    vector<vector<int>> B = {{9, 8, 7},
                            {6, 5, 4},
                            {3, 2, 1}};

    // Calculate the number of rows each process will compute
    int rowsPerProcess = M / world_size;
    int extraRows = M % world_size;
    int startRow = world_rank * rowsPerProcess + min(world_rank, extraRows);
    int endRow = startRow + rowsPerProcess + (world_rank < extraRows);

    // Each process performs its part of the computation
    multiplyMatrixPart(A, B, C, startRow, endRow, N, P);

    // Gathering the results
    if (world_rank == 0) {
        // Collect results from all processes
        for (int i = 1; i < world_size; ++i) {
            int startRowOther = i * rowsPerProcess + min(i, extraRows);
            int endRowOther = startRowOther + rowsPerProcess + (i < extraRows);
            int numRowsOther = endRowOther - startRowOther;

            for (int j = 0; j < numRowsOther; ++j) {
                MPI_Recv(C[startRowOther + j].data(), P, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }
    } else {
        // Send results to the root process
       
        for (int i = startRow; i < endRow; ++i) {
            MPI_Send(C[i].data(), P, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }
    // Print the result matrix at the root process
    if (world_rank == 0) {
        cout << "Resultant Matrix:" << endl;
        for (const auto& row : C) {
            for (int val : row) {
                cout << val << " ";
            }
            cout << endl;
        }
    }

    MPI_Finalize();
    return 0;
}