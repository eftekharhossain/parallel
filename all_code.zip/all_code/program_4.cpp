#include <iostream>
#include <string>
#include <mpi.h>

using namespace std;

int main(int argc, char** argv) {
    int rank, size;
    MPI_Init(&argc, &argv); // Initialize the MPI environment
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); // Get the rank of the process
    MPI_Comm_size(MPI_COMM_WORLD, &size); // Get the number of processes

    // Ensure that there are exactly two processes
    if (size != 2) {
        cerr << "This program requires exactly 2 processes." << endl;
        MPI_Finalize(); // Finalize the MPI environment
        return 1;
    }

    const int MAX_STRING = 100; // Maximum string length
    char word[MAX_STRING]; // Buffer for the word

    if (rank == 0) {
        // Process 0: Sends a word and receives the modified word back
        string input_word = "Hello"; // Word to be sent
        strncpy(word, input_word.c_str(), MAX_STRING);
        word[MAX_STRING - 1] = '\0'; // Ensure null termination

        MPI_Ssend(word, strlen(word) + 1, MPI_CHAR, 1, 0, MPI_COMM_WORLD); // Synchronously send the word to process 1
        MPI_Recv(word, MAX_STRING, MPI_CHAR, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); // Receive the modified word back

        cout << "Process 0 received back: " << word << endl;
    } else if (rank == 1) {
        // Process 1: Receives a word, modifies it, and sends it back
        MPI_Recv(word, MAX_STRING, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); // Receive the word from process 0

        // Toggle the case of each character in the word
        for (int i = 0; word[i] != '\0'; ++i) {
            if (islower(word[i])) word[i] = toupper(word[i]);
            else if (isupper(word[i])) word[i] = tolower(word[i]);
        }

        MPI_Ssend(word, strlen(word) + 1, MPI_CHAR, 0, 0, MPI_COMM_WORLD); // Synchronously send the modified word back to process 0
    }

    MPI_Finalize(); // Finalize the MPI environment
    return 0;
}
